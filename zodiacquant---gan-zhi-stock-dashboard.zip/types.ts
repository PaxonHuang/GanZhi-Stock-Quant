
export interface StockData {
  date: string; // ISO string
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  ganzhi?: string;
  wuxing?: string;
}

export interface StockInfo {
  symbol: string;
  name: string;
  price: number;
  change: number;
  changePercent: number;
  history: StockData[];
}

export type ChartInterval = 'Daily' | 'Xun' | 'Monthly';

export enum WuXing {
  WOOD = '木',
  FIRE = '火',
  EARTH = '土',
  METAL = '金',
  WATER = '水'
}
