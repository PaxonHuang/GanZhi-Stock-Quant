
import React, { useMemo, useState, useEffect } from 'react';
import { 
  ComposedChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Line,
  ReferenceLine
} from 'recharts';
import { ChartInterval } from '../types';
import { WUXING_COLORS } from '../constants';

interface StockChartProps {
  data: any[]; 
  interval: ChartInterval;
}

/**
 * 标准蜡烛图组件 (Candlestick)
 * 严格对齐影线与实体，采用实心填充
 */
const CandlestickItem = (props: any) => {
  const { x, width, open, close, high, low, yScale } = props;
  
  if (!yScale || open === undefined || close === undefined) return null;

  const isUp = close >= open;
  // 阳红阴绿，色值参考主流交易软件
  const color = isUp ? '#f6465d' : '#2ebd85'; 
  
  const yOpen = yScale(open);
  const yClose = yScale(close);
  const yHigh = yScale(high);
  const yLow = yScale(low);

  const centerX = x + width / 2;
  const bodyTop = Math.min(yOpen, yClose);
  const bodyBottom = Math.max(yOpen, yClose);
  const bodyHeight = Math.max(Math.abs(yOpen - yClose), 2);

  return (
    <g>
      {/* 上下影线：极细直线穿透 */}
      <line
        x1={centerX}
        y1={yHigh}
        x2={centerX}
        y2={yLow}
        stroke={color}
        strokeWidth={1}
      />
      {/* 蜡烛实体：实心填充 */}
      <rect
        x={x}
        y={bodyTop}
        width={width}
        height={bodyHeight}
        fill={color}
        stroke={color}
        strokeWidth={0.5}
      />
    </g>
  );
};

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    const isUp = data.close >= data.open;
    const colorClass = isUp ? 'text-[#f6465d]' : 'text-[#2ebd85]';
    
    return (
      <div className="bg-[#1e2329] border border-[#30363d] p-3 rounded shadow-2xl text-[11px] font-mono backdrop-blur-md z-50">
        <div className="flex justify-between items-center gap-6 mb-2 border-b border-[#474d57] pb-1">
          <span className="text-[#848e9c] font-bold">{new Date(data.date).toLocaleDateString()}</span>
          <span className="text-yellow-500 font-bold">{data.ganzhi} ({data.wuxing})</span>
        </div>
        <div className="grid grid-cols-2 gap-x-6 gap-y-1">
          <span className="text-[#848e9c]">开盘:</span> <span className="text-white text-right">{data.open.toFixed(2)}</span>
          <span className="text-[#848e9c]">最高:</span> <span className="text-[#f6465d] text-right font-bold">{data.high.toFixed(2)}</span>
          <span className="text-[#848e9c]">最低:</span> <span className="text-[#2ebd85] text-right font-bold">{data.low.toFixed(2)}</span>
          <span className="text-[#848e9c]">收盘:</span> <span className={`text-right font-bold ${colorClass}`}>{data.close.toFixed(2)}</span>
          <div className="col-span-2 h-px bg-[#474d57] my-1"></div>
          <span className="text-[#848e9c]">MA5:</span> <span className="text-white text-right">{data.ma5?.toFixed(2) || '--'}</span>
          <span className="text-[#848e9c]">MA10:</span> <span className="text-yellow-400 text-right">{data.ma10?.toFixed(2) || '--'}</span>
          <span className="text-[#848e9c]">MA20:</span> <span className="text-blue-400 text-right">{data.ma20?.toFixed(2) || '--'}</span>
        </div>
      </div>
    );
  }
  return null;
};

const StockChart: React.FC<StockChartProps> = ({ data, interval }) => {
  const [viewCount, setViewCount] = useState(60);

  useEffect(() => {
    setViewCount(interval === 'Daily' ? 60 : 45);
  }, [interval]);

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const zoomIn = e.deltaY < 0;
    const step = Math.max(2, Math.ceil(viewCount * 0.15));
    setViewCount(prev => {
      const next = zoomIn ? prev - step : prev + step;
      return Math.min(Math.max(15, next), data.length);
    });
  };

  const visibleData = useMemo(() => {
    return data.slice(-viewCount);
  }, [data, viewCount]);

  const yDomain = useMemo(() => {
    if (visibleData.length === 0) return ['auto', 'auto'];
    const values = visibleData.flatMap(d => [d.high, d.low, d.ma5, d.ma10, d.ma20].filter(v => v != null));
    const min = Math.min(...values);
    const max = Math.max(...values);
    const range = max - min;
    return [
      parseFloat((min - range * 0.12).toFixed(2)),
      parseFloat((max + range * 0.12).toFixed(2))
    ];
  }, [visibleData]);

  return (
    <div className="h-full w-full cursor-crosshair select-none bg-[#0b0e11]" onWheel={handleWheel}>
      <ResponsiveContainer width="100%" height="100%">
        <ComposedChart data={visibleData} margin={{ top: 15, right: 0, left: 0, bottom: 5 }}>
          {/* 网格线设置，增强深度感 */}
          <CartesianGrid strokeDasharray="0" stroke="#1c2128" vertical={false} />
          
          <XAxis 
            dataKey="date" 
            axisLine={{ stroke: '#30363d' }}
            tickLine={false}
            tick={({ x, y, payload, index }) => {
                const step = Math.ceil(viewCount / 6);
                if (index % step !== 0) return null;
                const d = visibleData[index];
                return (
                  <g transform={`translate(${x},${y})`}>
                    <text x={0} y={0} dy={16} textAnchor="middle" fill="#848e9c" fontSize={10} fontFamily="monospace">
                      {new Date(payload.value).toLocaleDateString('zh-CN', { month: '2-digit', day: '2-digit' })}
                    </text>
                    <text x={0} y={0} dy={32} textAnchor="middle" fill={WUXING_COLORS[d?.wuxing || '']} fontSize={11} fontWeight="bold">
                      {d?.ganzhi}
                    </text>
                  </g>
                );
            }}
            interval={0}
          />

          <YAxis 
            orientation="right" 
            domain={yDomain} 
            axisLine={{ stroke: '#30363d' }}
            tickLine={false}
            mirror={true}
            tick={{ fill: '#848e9c', fontSize: 10, fontFamily: 'monospace' }}
            tickFormatter={(val) => val.toLocaleString()}
            allowDataOverflow={true}
          />

          <Tooltip 
            content={<CustomTooltip />} 
            cursor={{ stroke: '#474d57', strokeWidth: 1, strokeDasharray: '4 4' }}
            isAnimationActive={false}
          />
          
          {/* 主蜡烛图层 */}
          <Bar 
            dataKey="high" 
            shape={<CandlestickItem />} 
            isAnimationActive={false} 
          />
          
          {/* 金融级均线系统 */}
          <Line type="linear" dataKey="ma5" stroke="#ffffff" dot={false} strokeWidth={1} opacity={0.6} isAnimationActive={false} connectNulls />
          <Line type="linear" dataKey="ma10" stroke="#ffeb3b" dot={false} strokeWidth={1} opacity={0.6} isAnimationActive={false} connectNulls />
          <Line type="linear" dataKey="ma20" stroke="#2196f3" dot={false} strokeWidth={1} opacity={0.6} isAnimationActive={false} connectNulls />

          {/* 最新价格指示线 */}
          {visibleData.length > 0 && (
             <ReferenceLine 
                y={visibleData[visibleData.length - 1].close} 
                stroke="#474d57" 
                strokeDasharray="2 2" 
                label={{ 
                  position: 'right', 
                  value: visibleData[visibleData.length - 1].close.toFixed(2), 
                  fill: visibleData[visibleData.length - 1].close >= visibleData[visibleData.length - 1].open ? '#f6465d' : '#2ebd85', 
                  fontSize: 11,
                  fontWeight: 'bold',
                  offset: 10
                }} 
             />
          )}
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
};

export default StockChart;
