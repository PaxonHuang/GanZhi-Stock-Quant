
import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { StockInfo, WuXing } from '../types';
import { WUXING_COLORS } from '../constants';

interface AnalysisProps {
  stock: StockInfo;
}

const FiveElementsAnalysis: React.FC<AnalysisProps> = ({ stock }) => {
  const [analysis, setAnalysis] = useState<string>('');
  const [loading, setLoading] = useState(false);

  const performAnalysis = async () => {
    setLoading(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const prompt = `
        你是一位精通中国传统易经、五行、天干地支理论的资深量化分析师。
        当前分析对象：${stock.name} (${stock.symbol})
        当前股价：${stock.price.toFixed(2)}
        涨跌幅：${stock.changePercent.toFixed(2)}%
        
        请结合今日的干支和五行属性，给出一段深度的“玄学量化”分析：
        1. 结合该行业的五行属性（例如科技属金，医药属木）。
        2. 根据天干地支的生克制化给出操盘建议。
        3. 给出今日的“气运”评级。
        
        字数在200字左右，风格专业且富有神秘感。
      `;

      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: prompt,
      });

      setAnalysis(response.text || '解析受阻，天机不可泄露。');
    } catch (error) {
      console.error(error);
      setAnalysis('星象运行紊乱，暂无法建立感应。请检查网络或配置。');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    performAnalysis();
  }, [stock.symbol]);

  return (
    <div className="bg-[#0d1117] border border-[#30363d] rounded-lg p-5 h-full flex flex-col">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold flex items-center gap-2">
          <span className="text-yellow-500">☯</span> 五行玄学分析
        </h3>
        <button 
          onClick={performAnalysis}
          className="text-xs text-[#58a6ff] hover:underline"
          disabled={loading}
        >
          {loading ? '卜算中...' : '重新占卜'}
        </button>
      </div>

      <div className="flex-1 overflow-y-auto stock-scrollbar space-y-4">
        <div className="grid grid-cols-5 gap-2 text-center text-[10px]">
          {Object.entries(WUXING_COLORS).map(([name, color]) => (
            <div key={name} className="flex flex-col items-center">
              <div className="w-8 h-8 rounded-full flex items-center justify-center mb-1 text-black font-bold" style={{ backgroundColor: color }}>
                {name}
              </div>
              <div className="text-[#8b949e]">{(Math.random() * 100).toFixed(0)}%</div>
            </div>
          ))}
        </div>

        <div className="p-4 bg-[#161b22] rounded-lg border-l-4 border-yellow-500 italic text-sm text-[#c9d1d9] leading-relaxed">
          {loading ? (
            <div className="space-y-2 animate-pulse">
              <div className="h-4 bg-gray-700 rounded w-3/4"></div>
              <div className="h-4 bg-gray-700 rounded"></div>
              <div className="h-4 bg-gray-700 rounded w-5/6"></div>
            </div>
          ) : (
            analysis
          )}
        </div>
        
        <div className="mt-4 pt-4 border-t border-[#30363d]">
          <h4 className="text-xs font-bold text-[#8b949e] mb-2">气运罗盘</h4>
          <div className="flex flex-wrap gap-2">
            <span className="px-2 py-1 rounded bg-red-900/30 text-red-400 text-[10px] border border-red-500/30">火旺剋金</span>
            <span className="px-2 py-1 rounded bg-green-900/30 text-green-400 text-[10px] border border-green-500/30">木气回升</span>
            <span className="px-2 py-1 rounded bg-blue-900/30 text-blue-400 text-[10px] border border-blue-500/30">水生万物</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FiveElementsAnalysis;
