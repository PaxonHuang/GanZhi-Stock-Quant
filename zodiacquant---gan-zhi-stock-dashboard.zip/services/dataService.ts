
import { StockData, StockInfo, ChartInterval } from '../types';
import { getGanZhi, getWuXingFromGan } from '../utils/ganzhi';

const calculateMA = (data: StockData[], period: number): (number | null)[] => {
  const ma = [];
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      ma.push(null);
    } else {
      const sum = data.slice(i - period + 1, i + 1).reduce((acc, val) => acc + val.close, 0);
      ma.push(sum / period);
    }
  }
  return ma;
};

export const generateMockStockData = (symbol: string, name: string): StockInfo => {
  const data: StockData[] = [];
  const now = new Date();
  
  // Set realistic base prices
  let basePrice = 50 + Math.random() * 500;
  let volatilityScale = 0.02;

  if (name.includes('指数')) {
    if (symbol === '000001') basePrice = 3050; // SSE
    if (symbol === '000300') basePrice = 3500; // CSI 300
    if (symbol === '399006') basePrice = 1800; // ChiNext
    volatilityScale = 0.01; // Indices are less volatile
  } else {
    if (symbol === '600519') basePrice = 1650; // Moutai
    if (symbol === '300750') basePrice = 150;  // CATL
    if (symbol === '688981') basePrice = 45;   // SMIC
    if (symbol === '002594') basePrice = 210;  // BYD
  }

  // Generate 250 days of data to have enough for MA20
  for (let i = 250; i >= 0; i--) {
    const date = new Date(now);
    date.setDate(now.getDate() - i);
    
    // Skip weekends
    const day = date.getDay();
    if (day === 0 || day === 6) continue;

    const volatility = basePrice * volatilityScale;
    const change = (Math.random() - 0.48) * volatility; // Slight upward bias
    const open = basePrice + change;
    const close = open + (Math.random() - 0.5) * (volatility * 0.8);
    const high = Math.max(open, close) + Math.random() * (volatility * 0.3);
    const low = Math.min(open, close) - Math.random() * (volatility * 0.3);
    const volume = name.includes('指数') 
      ? Math.floor(200000000 + Math.random() * 100000000) 
      : Math.floor(Math.random() * 2000000);
    
    const ganzhi = getGanZhi(date);
    const wuxing = getWuXingFromGan(ganzhi[0]);

    data.push({
      date: date.toISOString(),
      open,
      high,
      low,
      close,
      volume,
      ganzhi,
      wuxing
    });
    
    basePrice = close;
  }

  const last = data[data.length - 1];
  const secondLast = data[data.length - 2];
  const change = last.close - secondLast.close;
  const changePercent = (change / secondLast.close) * 100;

  return {
    symbol,
    name,
    price: last.close,
    change,
    changePercent,
    history: data
  };
};

export const aggregateData = (data: StockData[], interval: ChartInterval): any[] => {
  let baseData = data;
  if (interval !== 'Daily') {
    const aggregated: StockData[] = [];
    let currentGroup: StockData[] = [];

    const checkThreshold = (date: Date, nextDate: Date) => {
      if (interval === 'Xun') {
        const gz = getGanZhi(date);
        const nextGz = getGanZhi(nextDate);
        return gz[0] === '癸' && nextGz[0] === '甲';
      } else if (interval === 'Monthly') {
        return date.getMonth() !== nextDate.getMonth();
      }
      return false;
    };

    for (let i = 0; i < data.length; i++) {
      currentGroup.push(data[i]);
      const isLast = i === data.length - 1;
      const nextDate = !isLast ? new Date(data[i + 1].date) : null;
      const currentDate = new Date(data[i].date);

      if (isLast || (nextDate && checkThreshold(currentDate, nextDate))) {
        const open = currentGroup[0].open;
        const close = currentGroup[currentGroup.length - 1].close;
        const high = Math.max(...currentGroup.map(d => d.high));
        const low = Math.min(...currentGroup.map(d => d.low));
        const volume = currentGroup.reduce((sum, d) => sum + d.volume, 0);
        
        aggregated.push({
          date: currentGroup[currentGroup.length - 1].date,
          open,
          high,
          low,
          close,
          volume,
          ganzhi: currentGroup[currentGroup.length - 1].ganzhi,
          wuxing: currentGroup[currentGroup.length - 1].wuxing,
        });
        currentGroup = [];
      }
    }
    baseData = aggregated;
  }

  // Calculate MAs on the aggregated set
  const ma5 = calculateMA(baseData, 5);
  const ma10 = calculateMA(baseData, 10);
  const ma20 = calculateMA(baseData, 20);

  return baseData.map((d, i) => ({
    ...d,
    ma5: ma5[i],
    ma10: ma10[i],
    ma20: ma20[i]
  }));
};
