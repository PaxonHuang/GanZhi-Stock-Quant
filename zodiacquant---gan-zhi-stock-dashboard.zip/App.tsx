
import React, { useState, useEffect, useMemo } from 'react';
import { STOCK_GROUPS, SAMPLE_STOCKS } from './constants';
import { StockInfo, ChartInterval } from './types';
import { generateMockStockData, aggregateData } from './services/dataService';
import StockChart from './components/StockChart';
import FiveElementsAnalysis from './components/FiveElementsAnalysis';
import { Search, Bell, Settings, User, Activity, TrendingUp, Cpu, Landmark, ChevronDown } from 'lucide-react';

const App: React.FC = () => {
  const [selectedSymbol, setSelectedSymbol] = useState(SAMPLE_STOCKS[0].symbol);
  const [interval, setInterval] = useState<ChartInterval>('Daily');
  const [stocks, setStocks] = useState<Record<string, StockInfo>>({});
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    const newStocks: Record<string, StockInfo> = {};
    SAMPLE_STOCKS.forEach(s => {
      newStocks[s.symbol] = generateMockStockData(s.symbol, s.name);
    });
    setStocks(newStocks);
  }, []);

  const currentStock = stocks[selectedSymbol];
  
  const aggregatedHistory = useMemo(() => {
    if (!currentStock) return [];
    return aggregateData(currentStock.history, interval);
  }, [currentStock, interval]);

  const latestK = aggregatedHistory.length > 0 ? aggregatedHistory[aggregatedHistory.length - 1] : null;

  const filteredGroups = useMemo(() => {
    if (!searchQuery) return STOCK_GROUPS;
    return STOCK_GROUPS.map(group => ({
      ...group,
      items: group.items.filter(item => 
        item.name.includes(searchQuery) || item.symbol.includes(searchQuery)
      )
    })).filter(group => group.items.length > 0);
  }, [searchQuery]);

  if (!currentStock) return (
    <div className="h-screen flex flex-col items-center justify-center bg-[#0d1117] gap-4">
      <Activity className="w-12 h-12 text-yellow-500 animate-spin" />
      <div className="text-yellow-500 font-serif text-xl tracking-[0.4em] uppercase">阴阳开合 · 正在启盘</div>
    </div>
  );

  const groupIcons: Record<string, React.ReactNode> = {
    '大盘指数': <TrendingUp className="w-3 h-3" />,
    '核心科技': <Cpu className="w-3 h-3" />,
    '消费金融': <Landmark className="w-3 h-3" />
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden text-sm bg-[#0b0e11] selection:bg-yellow-500/30">
      {/* 左侧侧边栏 */}
      <aside className="w-64 border-r border-[#1e2329] flex flex-col bg-[#0b0e11] shadow-2xl z-20">
        <div className="p-5 flex items-center gap-3 border-b border-[#1e2329]">
          <div className="bg-gradient-to-br from-yellow-400 to-orange-500 p-1.5 rounded shadow-[0_0_15px_rgba(234,179,8,0.2)]">
            <Activity className="w-5 h-5 text-black" />
          </div>
          <h1 className="text-sm font-bold text-white tracking-[0.2em] font-serif uppercase">Zodiac Quant</h1>
        </div>
        
        <div className="p-4">
          <div className="relative group">
            <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-[#848e9c]" />
            <input 
              type="text" 
              placeholder="代码/拼音/名称"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-[#1e2329] border border-transparent rounded-md py-2.5 pl-9 pr-3 text-[11px] focus:border-yellow-500 outline-none transition-all font-mono placeholder:text-[#474d57]"
            />
          </div>
        </div>

        <div className="flex-1 overflow-y-auto stock-scrollbar pb-10">
          {filteredGroups.map((group, gIdx) => (
            <div key={gIdx} className="mb-4">
              <div className="px-5 py-2 text-[10px] font-bold text-[#848e9c] uppercase tracking-[0.2em] flex items-center gap-2 bg-[#1e2329]/30">
                {groupIcons[group.label]}
                {group.label}
              </div>
              <div className="mt-1">
                {group.items.map(s => {
                  const stock = stocks[s.symbol];
                  if (!stock) return null;
                  const isSelected = selectedSymbol === s.symbol;
                  return (
                    <button 
                      key={s.symbol}
                      onClick={() => setSelectedSymbol(s.symbol)}
                      className={`w-full text-left px-5 py-3 border-b border-[#1e2329]/40 transition-all flex items-center justify-between group relative ${isSelected ? 'bg-[#1e2329]' : 'hover:bg-[#1e2329]/50'}`}
                    >
                      {isSelected && <div className="absolute left-0 top-0 bottom-0 w-1 bg-yellow-500 shadow-[2px_0_10px_rgba(234,179,8,0.5)]"></div>}
                      <div className="min-w-0">
                        <div className={`font-bold text-xs truncate ${isSelected ? 'text-yellow-500' : 'text-gray-200'}`}>{s.name}</div>
                        <div className="text-[10px] text-[#848e9c] font-mono mt-0.5">{s.symbol}</div>
                      </div>
                      <div className="text-right">
                        <div className={`font-mono text-xs font-bold ${stock.change >= 0 ? 'text-[#f6465d]' : 'text-[#2ebd85]'}`}>
                          {stock.price.toFixed(2)}
                        </div>
                        <div className={`text-[10px] font-bold mt-0.5 ${stock.change >= 0 ? 'text-[#f6465d]' : 'text-[#2ebd85]'}`}>
                          {stock.changePercent >= 0 ? '+' : ''}{stock.changePercent.toFixed(2)}%
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </div>
      </aside>

      {/* 主展示区 */}
      <main className="flex-1 flex flex-col bg-[#0b0e11] min-w-0">
        <header className="h-16 border-b border-[#1e2329] flex items-center justify-between px-8 bg-[#0b0e11]/90 backdrop-blur-md z-10 shadow-sm">
          <div className="flex items-center gap-10">
            <div className="flex items-center gap-5">
              <h2 className="text-xl font-bold text-white font-serif">{currentStock.name} <span className="font-mono text-[11px] text-[#848e9c] ml-1 font-normal opacity-50">{currentStock.symbol}</span></h2>
              <div className="flex items-baseline gap-4 ml-2">
                 <span className={`text-2xl font-mono font-bold tracking-tighter ${currentStock.change >= 0 ? 'text-[#f6465d]' : 'text-[#2ebd85]'}`}>
                    {currentStock.price.toFixed(2)}
                 </span>
                 <div className={`flex flex-col text-[11px] font-mono font-bold leading-tight ${currentStock.change >= 0 ? 'text-[#f6465d]' : 'text-[#2ebd85]'}`}>
                    <span>{currentStock.change >= 0 ? '+' : ''}{currentStock.change.toFixed(2)}</span>
                    <span>{currentStock.changePercent.toFixed(2)}%</span>
                 </div>
              </div>
            </div>
            
            <div className="h-6 w-px bg-[#1e2329]" />

            <div className="flex bg-[#1e2329] p-1 rounded border border-[#30363d] shadow-inner">
              {(['Daily', 'Xun', 'Monthly'] as ChartInterval[]).map(i => (
                <button
                  key={i}
                  onClick={() => setInterval(i)}
                  className={`px-4 py-1 text-[11px] rounded transition-all font-bold ${interval === i ? 'bg-[#474d57] text-yellow-500' : 'text-[#848e9c] hover:text-white hover:bg-[#1e2329]'}`}
                >
                  {i === 'Daily' ? '日线' : i === 'Xun' ? '旬K' : '月线'}
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-6">
             <div className="flex items-center gap-4 text-[10px] font-mono text-[#848e9c] bg-[#1e2329]/80 px-4 py-2 rounded border border-[#30363d] shadow-lg">
                <div className="flex gap-4">
                   <div className="flex flex-col items-center">
                     <span className="text-[8px] opacity-30">岁次</span>
                     <span className="text-white">甲辰</span>
                   </div>
                   <div className="flex flex-col items-center border-l border-white/5 pl-4">
                     <span className="text-[8px] opacity-30">值日</span>
                     <span className="text-yellow-500 font-bold underline decoration-yellow-500/20">已未</span>
                   </div>
                </div>
                <div className="w-px h-6 bg-[#30363d]"></div>
                <div className="text-center">
                   <span className="text-[8px] opacity-30">时辰</span>
                   <div className="text-white font-bold">未时 (13-15)</div>
                </div>
             </div>
             <div className="flex gap-4">
               <Bell className="w-5 h-5 text-[#848e9c] hover:text-white cursor-pointer transition-all" />
               <Settings className="w-5 h-5 text-[#848e9c] hover:text-white cursor-pointer transition-all" />
               <User className="w-8 h-8 p-1.5 rounded-full bg-[#1e2329] border border-[#30363d] text-white shadow-xl" />
             </div>
          </div>
        </header>

        <div className="flex-1 flex overflow-hidden">
          <div className="flex-1 flex flex-col min-w-0">
            {/* 标准K线详情栏 (Daily Detail Bar) */}
            <div className="h-10 bg-[#161b22] border-b border-[#1e2329] flex items-center px-6 gap-8 text-[11px] font-mono overflow-x-auto whitespace-nowrap stock-scrollbar">
              <div className="flex items-center gap-2">
                <span className="text-[#848e9c]">日K线:</span>
                <span className="text-white font-bold">{new Date(latestK?.date || '').toLocaleDateString('zh-CN')}</span>
              </div>
              <div className="flex gap-5">
                <span className="text-[#848e9c]">开: <span className="text-white">{latestK?.open.toFixed(2)}</span></span>
                <span className="text-[#848e9c]">高: <span className="text-[#f6465d]">{latestK?.high.toFixed(2)}</span></span>
                <span className="text-[#848e9c]">低: <span className="text-[#2ebd85]">{latestK?.low.toFixed(2)}</span></span>
                <span className="text-[#848e9c]">收: <span className={latestK?.close >= latestK?.open ? 'text-[#f6465d]' : 'text-[#2ebd85]'}>{latestK?.close.toFixed(2)}</span></span>
              </div>
              <div className="flex gap-5 border-l border-white/10 pl-5">
                <span className="text-[#848e9c]">量: <span className="text-yellow-500/80">{(latestK?.volume / 10000).toFixed(2)}万</span></span>
                <span className="text-[#848e9c]">额: <span className="text-yellow-500/80">{(latestK?.volume * latestK?.close / 100000000).toFixed(2)}亿</span></span>
              </div>
              <div className="ml-auto flex gap-4 text-[#848e9c]">
                <span className="flex items-center gap-1 cursor-pointer hover:text-white transition-colors">指标 <ChevronDown className="w-3 h-3" /></span>
                <span className="flex items-center gap-1 cursor-pointer hover:text-white transition-colors">画线 <ChevronDown className="w-3 h-3" /></span>
              </div>
            </div>

            {/* K线主图 */}
            <div className="flex-[7] bg-[#0b0e11] relative border-b border-[#1e2329] shadow-[inset_0_0_40px_rgba(0,0,0,0.6)] overflow-hidden">
              <div className="absolute top-4 left-8 z-10 flex gap-6 text-[11px] font-mono bg-[#0b0e11]/70 px-4 py-2 rounded-sm border border-white/5 pointer-events-none backdrop-blur-md">
                <span className="flex items-center gap-2"><div className="w-3 h-0.5 bg-white opacity-80"></div> MA5: {latestK?.ma5?.toFixed(2)}</span>
                <span className="flex items-center gap-2"><div className="w-3 h-0.5 bg-[#ffeb3b] opacity-80"></div> MA10: {latestK?.ma10?.toFixed(2)}</span>
                <span className="flex items-center gap-2"><div className="w-3 h-0.5 bg-[#2196f3] opacity-80"></div> MA20: {latestK?.ma20?.toFixed(2)}</span>
              </div>
              <StockChart data={aggregatedHistory} interval={interval} />
            </div>
            
            {/* 成交量图 */}
            <div className="flex-1 bg-[#0b0e11] p-3 relative border-t border-[#1e2329]/50">
               <div className="absolute top-2 left-8 z-10 text-[10px] text-[#474d57] font-bold tracking-[0.2em] pointer-events-none uppercase opacity-60">成交量 VOL</div>
               <div className="h-full w-full flex items-end justify-between gap-[2px]">
                {aggregatedHistory.slice(-100).map((d, i) => (
                  <div 
                    key={i} 
                    className={`flex-1 min-w-[2px] transition-all hover:brightness-125 ${d.close >= d.open ? 'bg-[#f6465d]/20 border-t border-[#f6465d]/30' : 'bg-[#2ebd85]/20 border-t border-[#2ebd85]/30'}`}
                    style={{ height: `${Math.max(4, (d.volume / Math.max(...aggregatedHistory.map(v => v.volume))) * 90)}%` }}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* 右侧占卜分析栏 */}
          <div className="w-80 border-l border-[#1e2329] flex flex-col gap-2 p-3 bg-[#0b0e11] shadow-2xl">
             <div className="flex-1 overflow-hidden shadow-2xl rounded-lg">
                <FiveElementsAnalysis stock={currentStock} />
             </div>
             
             {/* 实时动态盘口 */}
             <div className="h-56 bg-[#1e2329]/40 border border-[#30363d] rounded-lg p-5 flex flex-col shadow-xl backdrop-blur-sm">
                <h4 className="text-[10px] font-bold text-white mb-4 flex items-center justify-between uppercase tracking-[0.2em] border-b border-[#30363d] pb-2">
                   <div className="flex items-center gap-2">
                     <div className="w-2 h-2 rounded-full bg-yellow-500 animate-pulse shadow-[0_0_12px_rgba(234,179,8,0.7)]"></div>
                     <span>实时盘口 TICKS</span>
                   </div>
                   <span className="text-[9px] text-[#848e9c] opacity-50">REALTIME</span>
                </h4>
                <div className="flex-1 overflow-y-auto space-y-2 pr-1 stock-scrollbar">
                   {[
                     { p: currentStock.price * 1.0004, v: 512, t: '15:00:00', c: 'text-[#f6465d]' },
                     { p: currentStock.price * 0.9997, v: 215, t: '14:59:58', c: 'text-[#2ebd85]' },
                     { p: currentStock.price, v: 15, t: '14:59:55', c: 'text-white' },
                     { p: currentStock.price * 1.0021, v: 2841, t: '14:59:52', c: 'text-[#f6465d]' },
                     { p: currentStock.price * 1.0009, v: 132, t: '14:59:50', c: 'text-[#f6465d]' },
                     { p: currentStock.price * 0.9991, v: 941, t: '14:59:45', c: 'text-[#2ebd85]' },
                   ].map((tick, idx) => (
                     <div key={idx} className="flex justify-between font-mono text-[11px] border-b border-white/5 pb-1 hover:bg-white/5 rounded-sm px-1 transition-colors">
                        <span className="text-[#474d57]">{tick.t}</span>
                        <span className={`${tick.c} font-bold`}>{tick.p.toFixed(2)}</span>
                        <span className="text-yellow-500/70">{tick.v}</span>
                     </div>
                   ))}
                </div>
             </div>
          </div>
        </div>
        
        <footer className="h-8 border-t border-[#1e2329] bg-[#0b0e11] px-8 flex items-center justify-between text-[10px] text-[#848e9c] font-mono shadow-2xl z-20">
          <div className="flex gap-12 items-center">
            <span className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-[#2ebd85] shadow-[0_0_12px_rgba(46,189,133,0.5)]"></div> 
              全网连接: 优 (14ms)
            </span>
            <div className="flex gap-8 border-l border-white/10 pl-8">
              <span>上证指数: <span className="text-[#f6465d] font-bold">3,124.51 +0.21%</span></span>
              <span>创业板指: <span className="text-[#2ebd85] font-bold">1,842.12 -1.04%</span></span>
              <span>成交额: <span className="text-white opacity-80">1.28 万亿</span></span>
            </div>
          </div>
          <div className="flex gap-4 items-center opacity-40 hover:opacity-100 transition-opacity">
            <span className="uppercase tracking-[0.3em] text-[10px] font-bold text-yellow-500/90">ZodiacQuant Pro Engine V1.2.7</span>
          </div>
        </footer>
      </main>
    </div>
  );
};

export default App;
